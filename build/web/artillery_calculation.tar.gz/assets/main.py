import asyncio

from artillery_calculation import main


asyncio.run(main())
